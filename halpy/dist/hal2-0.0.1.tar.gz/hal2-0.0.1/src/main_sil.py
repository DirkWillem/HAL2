import pymodbus.pdu as pdu
import pymodbus.pdu.register_message as reg_msg
import pymodbus.transaction.transaction as modbus_transaction

import hal2.sil.app as sil_app
import hal2.sil.peripherals.uart as uart


def _func_ptr(ptr, argtypes: list, restype):
    ptr.argtypes = argtypes
    ptr.restype = restype
    return ptr


class ModbusClient:
    _address: int
    _uart: uart.Uart

    def __init__(self, address: int, u: uart.Uart):
        self._address = address
        self._uart = u

    def read_holding_registers(self, start_addr: int, count: int, timeout: float = 1.0) -> pdu.ModbusPDU:
        self._uart.transmit(self._encode_request(reg_msg.ReadHoldingRegistersRequest(address=start_addr, count=count)))
        rx_data = self._uart.receive(timeout)
        if len(rx_data) == 0:
            raise TimeoutError("No MODBUS frame was received in time")
        return self._decode_response(rx_data)

    def write_holding_registers(self, start_addr: int, data: list[int], timeout: float = 1.0) -> pdu.ModbusPDU:
        self._uart.transmit(
            self._encode_request(reg_msg.WriteMultipleRegistersRequest(address=start_addr, registers=data)))
        rx_data = self._uart.receive(timeout)
        if len(rx_data) == 0:
            raise TimeoutError("No MODBUS frame was received in time")
        return self._decode_response(rx_data)

    def _encode_request(self, frame: pdu.ModbusPDU):
        rtu_framer = modbus_transaction.FramerRTU(pdu.DecodePDU(False))
        frame = rtu_framer.encode(bytes([frame.function_code]) + frame.encode(), self._address, 0)
        return frame

    def _decode_response(self, frame_bytes: bytes) -> pdu.ModbusPDU:
        decode_pdu = pdu.DecodePDU(False)
        rtu_framer = modbus_transaction.FramerRTU(decode_pdu)
        _, _, _, inner = rtu_framer.decode(frame_bytes)
        return decode_pdu.decode(inner)


if __name__ == "__main__":
    lib_path = "/Users/dirkvanwijk/Developer/ethermal/etherwall_firmware/build/cmake-build-debug/src/app/mostcal/libmostcal_sil.dylib"

    data = bytes([0x01, 0x03, 0x01, 0x00, 0x00, 0x01, 0x85, 0xF6])

    with sil_app.SilApp(lib_path) as app:
        client = ModbusClient(1, app.get_uart("ext_uart"))
        print(client.write_holding_registers(0x0100, [1]))
        print(client.read_holding_registers(0x0100, 1))